public class RuntimeTest {

    // run 100 of nancy


    // run 100 of the random one
    // get an average of how far they get i.e. how filled up the log gets
    // compare averages
}
