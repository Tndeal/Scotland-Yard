package uk.ac.bris.cs.scotlandyard.ui.ai;

public class Remote {
    public static void main(String[] args) {
        uk.ac.bris.cs.scotlandyard.remote.Main.main(args);
    }
}
